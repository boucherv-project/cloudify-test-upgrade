from setuptools import setup

setup(
    name='update-workflow',
    version='1.0',
    author='valentin.boucher@orange.com',
    packages=['update'],
    install_requires=['cloudify-plugins-common==3.3'],
)
 